export class SmCarCardInfo {
  constructor(public title: string,
              public subtitle: string,
              public src: string,
              public alt: string) { }
}