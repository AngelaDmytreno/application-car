import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mycars',
  templateUrl: './mycars.component.html',
  styleUrls: ['./mycars.component.scss']
})
export class MycarsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {}

}
