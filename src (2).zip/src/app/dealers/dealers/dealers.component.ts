import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daelrspage',
  templateUrl: './dealers.component.html',
  styleUrls: ['./dealers.component.scss']
})
export class DealersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {}

}
